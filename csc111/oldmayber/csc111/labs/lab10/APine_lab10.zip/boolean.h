#ifndef BOOLEAN_H
  #define BOOLEAN_H
  #define TRUE 1
  #define FALSE 0

  typedef int boolean;
#endif
